"""Qdrant 向量存储：collection 管理 + upsert + 权限 payload 过滤检索。"""

from __future__ import annotations

import uuid
from typing import Any

from qdrant_client import QdrantClient, models

from app.core.config import get_settings
from app.core.logging import get_logger
from app.embed.embedder import EMBED_DIM
from app.splitter.chunker import Chunk

logger = get_logger(__name__)

_client: QdrantClient | None = None

# 可见性等级：public < internal < restricted
VISIBILITY_LEVELS = {"public": 0, "internal": 1, "restricted": 2}


def visible_levels(user_visibility: str) -> list[str]:
    """用户可见的 visibility 集合（<= 用户等级）。"""
    level = VISIBILITY_LEVELS.get(user_visibility, 0)
    return [v for v, lv in VISIBILITY_LEVELS.items() if lv <= level]


def get_client() -> QdrantClient:
    global _client
    if _client is None:
        # timeout=120：大文档分批写入需更长写超时，避免负载高时 30s 默认超时中断
        _client = QdrantClient(url=get_settings().qdrant_url, timeout=120, check_compatibility=False)
    return _client


def ensure_collection() -> None:
    """创建 chunks collection：dense(1024, cosine) + 稀疏向量槽（模型原生稀疏，无 IDF modifier）。

    稀疏向量为嵌入模型原生输出（词表 index + 语义权重），不叠加 IDF；
    检测到 collection 配置不匹配（缺 dense / 稀疏带 IDF）时删除重建。
    """
    client = get_client()
    settings = get_settings()
    if client.collection_exists(settings.qdrant_collection):
        needs_recreate = False
        try:
            params = client.get_collection(settings.qdrant_collection).config.params
            vectors = params.vectors
            has_dense = isinstance(vectors, dict) and "dense" in vectors
            sv = params.sparse_vectors
            if isinstance(sv, dict):
                sp = sv.get("sparse")
                has_sparse_ok = sp is not None and getattr(sp, "modifier", None) is None
            else:
                has_sparse_ok = sv is not None and getattr(sv, "modifier", None) is None
            needs_recreate = not has_dense or not has_sparse_ok
        except Exception:
            needs_recreate = False
        if needs_recreate:
            logger.warning("collection %s 向量配置不匹配（期望 dense + 稀疏无 IDF），删除重建", settings.qdrant_collection)
            client.delete_collection(settings.qdrant_collection)
        else:
            return
    client.create_collection(
        collection_name=settings.qdrant_collection,
        vectors_config={
            "dense": models.VectorParams(size=EMBED_DIM, distance=models.Distance.COSINE),
        },
        sparse_vectors_config={
            "sparse": models.SparseVectorParams(),
        },
    )
    for field in ("org_id", "visibility", "chunk_type", "doc_id"):
        client.create_payload_index(
            collection_name=settings.qdrant_collection,
            field_name=field,
            field_schema=models.PayloadSchemaType.KEYWORD,
        )
    logger.info("collection created: %s", settings.qdrant_collection)


def upsert_chunks(
    doc_id: str,
    chunks: list[Chunk],
    dense_vectors: list[list[float]],
    doc_name: str,
    org_id: str,
    visibility: str,
    fiscal_year: int | None,
    fiscal_quarter: int | None,
    sparse_vectors: list[dict] | None = None,
) -> int:
    """写入向量点；权限字段进 payload；稀疏向量（阶段二）可选。"""
    client = get_client()
    settings = get_settings()
    points = []
    for idx, (chunk, vec) in enumerate(zip(chunks, dense_vectors)):
        payload: dict[str, Any] = {
            "chunk_id": chunk.id,
            "doc_id": doc_id,
            "doc_name": doc_name,
            "page": chunk.page,
            "section_path": chunk.section_path,
            "chunk_type": chunk.chunk_type,
            "org_id": org_id,
            "visibility": visibility,
            "token_count": chunk.token_count,
            "content": chunk.content,
        }
        if fiscal_year is not None:
            payload["fiscal_year"] = fiscal_year
        if fiscal_quarter is not None:
            payload["fiscal_quarter"] = fiscal_quarter
        if chunk.parent_id:
            payload["parent_id"] = chunk.parent_id
        if chunk.chunk_type == "table":
            # 表格结构化元数据（供过滤/展示）
            if chunk.table_headers is not None:
                payload["table_headers"] = chunk.table_headers
            if chunk.n_rows is not None:
                payload["n_rows"] = chunk.n_rows
            if chunk.n_cols is not None:
                payload["n_cols"] = chunk.n_cols
        # 结构块标记（财务表头/页眉/版式说明），检索时降权/排除
        if settings.structural_chunk_enabled:
            from app.parsers.structural import is_structural_chunk

            payload["is_structural"] = bool(is_structural_chunk(chunk.content))
        else:
            payload["is_structural"] = False
        vector: dict[str, Any] = {"dense": vec}
        if sparse_vectors is not None:
            sv = sparse_vectors[idx]
            vector["sparse"] = models.SparseVector(indices=sv["indices"], values=sv["values"])
        points.append(
            models.PointStruct(
                id=uuid.uuid5(uuid.NAMESPACE_DNS, f"{doc_id}:{chunk.id}").hex,
                vector=vector,
                payload=payload,
            )
        )
    for i in range(0, len(points), 64):
        client.upsert(
            collection_name=settings.qdrant_collection,
            points=points[i : i + 64],
        )
    logger.info("upserted %d points for doc %s", len(points), doc_id)
    return len(points)


def delete_doc(doc_id: str) -> int:
    client = get_client()
    res = client.delete(
        collection_name=get_settings().qdrant_collection,
        points_selector=models.FilterSelector(
            filter=models.Filter(
                must=[models.FieldCondition(key="doc_id", match=models.MatchValue(value=doc_id))]
            )
        ),
    )
    logger.info("deleted doc %s points", doc_id)
    # UpdateStatus 枚举不可直接 int()，统一返回 1 表示执行成功
    return 1 if getattr(res, "status", None) else 0


def _apply_structural(results: list[dict]) -> list[dict]:
    """结构块置后降权：把 is_structural 块移到末尾（rank 降级，RRF 贡献变小）。
    原 exclude/off 多模式实测对召回无影响，已收敛为单一降权行为。"""
    settings = get_settings()
    if not settings.structural_chunk_enabled:
        return results
    stable = [r for r in results if not r.get("is_structural")] + [
        r for r in results if r.get("is_structural")
    ]
    return stable


def _dedup_diverse(results: list[dict]) -> list[dict]:
    """召回多样性：对近重复内容去重（子串/包含关系视为同一片段，只保留首个最高分）。

    防止 dense 路返回同一表格/段落的多个复制块挤占 RRF 候选，让更可能含答案的多样化块得以上浮。
    """
    settings = get_settings()
    if not settings.retrieval_diversity_enabled:
        return results
    kept: list[dict] = []
    kept_norms: list[str] = []

    def _norm(s: str) -> str:
        return s.replace(",", "").replace(" ", "").replace("\n", "")

    for r in results:
        content = _norm(r.get("content") or "")
        if len(content) < 40:
            kept.append(r)
            continue
        dup = False
        for k in kept_norms:
            if content in k or k in content:
                dup = True
                break
        if not dup:
            kept.append(r)
            kept_norms.append(content)
    return kept


def _year_filter_condition(fiscal_year: int | None, fiscal_years: list[int] | None) -> models.Condition | None:
    """年份过滤条件：单值 MatchValue；多值（降级 L2 前后年窗口）MatchAny；均无则 None。"""
    if fiscal_years:
        return models.FieldCondition(key="fiscal_year", match=models.MatchAny(any=list(fiscal_years)))
    if fiscal_year is not None:
        return models.FieldCondition(key="fiscal_year", match=models.MatchValue(value=fiscal_year))
    return None


def search_dense(
    query_vector: list[float],
    org_id: str,
    user_visibility: str,
    top_k: int,
    chunk_type: str | None = None,
    exclude_chunk_types: list[str] | None = None,
    fiscal_year: int | None = None,
    fiscal_years: list[int] | None = None,
    doc_ids: list[str] | None = None,
) -> list[dict]:
    """单路稠密检索，强制注入权限 payload 过滤；可追加年份过滤（陈旧文档防护）与文档过滤（主体预过滤）。"""
    client = get_client()
    must: list[models.Condition] = [
        models.FieldCondition(key="org_id", match=models.MatchValue(value=org_id)),
        models.FieldCondition(
            key="visibility",
            match=models.MatchAny(any=visible_levels(user_visibility)),
        ),
    ]
    yf = _year_filter_condition(fiscal_year, fiscal_years)
    if yf is not None:
        must.append(yf)
    if doc_ids:
        must.append(models.FieldCondition(key="doc_id", match=models.MatchAny(any=doc_ids)))
    if chunk_type:
        must.append(models.FieldCondition(key="chunk_type", match=models.MatchValue(value=chunk_type)))
    must_not = None
    if exclude_chunk_types:
        must_not = [
            models.FieldCondition(key="chunk_type", match=models.MatchAny(any=exclude_chunk_types))
        ]
    hits = client.query_points(
        collection_name=get_settings().qdrant_collection,
        query=query_vector,
        using="dense",
        query_filter=models.Filter(must=must, must_not=must_not),
        limit=top_k,
        with_payload=True,
    ).points
    results = []
    for h in hits:
        p = h.payload or {}
        results.append(
            {
                "chunk_id": p.get("chunk_id"),
                "doc_id": p.get("doc_id"),
                "doc_name": p.get("doc_name"),
                "page": p.get("page"),
                "section_path": p.get("section_path", ""),
                "chunk_type": p.get("chunk_type", "text"),
                "content": p.get("content", ""),
                "parent_id": p.get("parent_id"),
                "score": h.score,
                # 检索后二次校验（权限）
                "org_id": p.get("org_id"),
                "visibility": p.get("visibility"),
                "is_structural": bool(p.get("is_structural")),
            }
        )
    return _dedup_diverse(_apply_structural(results))


def search_sparse(
    query_sparse: dict,
    org_id: str,
    user_visibility: str,
    top_k: int,
    chunk_type: str | None = None,
    exclude_chunk_types: list[str] | None = None,
    fiscal_year: int | None = None,
    fiscal_years: list[int] | None = None,
    doc_ids: list[str] | None = None,
) -> list[dict]:
    """稀疏路召回（模型原生稀疏：词表 index + 语义权重），强制权限过滤；可追加年份/文档过滤。"""
    client = get_client()
    must: list[models.Condition] = [
        models.FieldCondition(key="org_id", match=models.MatchValue(value=org_id)),
        models.FieldCondition(
            key="visibility",
            match=models.MatchAny(any=visible_levels(user_visibility)),
        ),
    ]
    yf = _year_filter_condition(fiscal_year, fiscal_years)
    if yf is not None:
        must.append(yf)
    if doc_ids:
        must.append(models.FieldCondition(key="doc_id", match=models.MatchAny(any=doc_ids)))
    if chunk_type:
        must.append(models.FieldCondition(key="chunk_type", match=models.MatchValue(value=chunk_type)))
    must_not = None
    if exclude_chunk_types:
        must_not = [
            models.FieldCondition(key="chunk_type", match=models.MatchAny(any=exclude_chunk_types))
        ]
    hits = client.query_points(
        collection_name=get_settings().qdrant_collection,
        query=models.SparseVector(indices=query_sparse["indices"], values=query_sparse["values"]),
        using="sparse",
        query_filter=models.Filter(must=must, must_not=must_not),
        limit=top_k,
        with_payload=True,
    ).points
    results = []
    for h in hits:
        p = h.payload or {}
        results.append(
            {
                "chunk_id": p.get("chunk_id"),
                "doc_id": p.get("doc_id"),
                "doc_name": p.get("doc_name"),
                "page": p.get("page"),
                "section_path": p.get("section_path", ""),
                "chunk_type": p.get("chunk_type", "text"),
                "content": p.get("content", ""),
                "parent_id": p.get("parent_id"),
                "score": h.score,
                "org_id": p.get("org_id"),
                "visibility": p.get("visibility"),
                "is_structural": bool(p.get("is_structural")),
            }
        )
    return _apply_structural(results)


def fetch_payloads(doc_id: str, chunk_ids: list[str]) -> dict[str, dict]:
    """按 chunk_id 取 payload（点 id 幂等 = uuid5(doc_id:chunk_id)），用于父块上下文扩展。"""
    if not chunk_ids:
        return {}
    client = get_client()
    ids = [uuid.uuid5(uuid.NAMESPACE_DNS, f"{doc_id}:{cid}").hex for cid in chunk_ids]
    pts = client.retrieve(
        collection_name=get_settings().qdrant_collection,
        ids=ids,
        with_payload=True,
    )
    return {p.payload.get("chunk_id"): p.payload for p in pts if p.payload}
