# 安装与下载记录

> 记录本机为运行「多模态财报深度分析 RAG 系统」所下载的内容与安装路径，便于环境迁移与排查。
> 记录时间：2026-08-06。环境：Windows / PowerShell 5，项目根目录 `c:\Users\admin\Desktop\work\show\newrag`。

## 1. Python 虚拟环境与依赖

| 项 | 路径 / 值 |
| --- | --- |
| 虚拟环境 | `c:\Users\admin\Desktop\work\show\newrag\backend\.venv` |
| Python | 3.13.9（系统级，位于 `C:\ComputerLangage\Python`） |
| 依赖清单 | `c:\Users\admin\Desktop\work\show\newrag\backend\requirements.txt` |

安装命令（因默认源下载缓慢，实际使用阿里云镜像）：

```powershell
python -m venv .venv
.\.venv\Scripts\pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/
```

> 备注：清华源 `pypi.tuna.tsinghua.edu.cn` 对部分包返回 403，已弃用；阿里云源可用。

### 已安装关键包（实测版本）

| 包 | 版本 | 用途 |
| --- | --- | --- |
| fastapi | 0.141.1 | Web 框架 |
| uvicorn | 0.52.1 | ASGI 服务器 |
| pydantic | 2.13.4 | 配置/校验 |
| pydantic-settings | 2.14.2 | .env 配置 |
| sse-starlette | 2.4.1 | SSE 流式输出 |
| qdrant-client | 1.19.0 | 向量库客户端（服务端 1.13.4，已关闭版本强校验） |
| redis | 5.3.1 | 缓存/队列客户端 |
| SQLAlchemy | 2.0.51 | SQLite 登记库 ORM |
| pymupdf | 1.28.0 | PDF 解析（文本/版式） |
| pdfplumber | 0.11.10 | PDF 表格提取 |
| python-docx | 1.2.0 | DOCX 解析 |
| openpyxl | 3.1.5 | XLSX 解析 |
| openai | 2.53.0 | LLM/嵌入客户端（DeepSeek / 百炼 OpenAI 兼容） |
| beautifulsoup4 | 4.15.0 | 财报抓取工具：SEC 年报 HTML 清洗（`tools/fetch_reports.py`） |
| tiktoken | 0.13.0 | token 估算 |
| httpx | 0.28.1 | HTTP 客户端 |
| numpy | 2.5.1 | 向量计算 |
| pytest | 9.1.1 | 测试 |

## 2. 嵌入模型（百炼 API）

| 项 | 值 |
| --- | --- |
| 模型 | `qwen3.7-text-embedding`（阿里云百炼，稠密 1024 维 + 模型原生稀疏） |
| 后端 | `api`（`EMBEDDING_BACKEND=api`，运行时映射 DashScope 原生 `/api/v1`） |
| API 端点 | `https://dashscope.aliyuncs.com/compatible-mode/v1`（配置值；实际走原生 `/api/v1`，一次返回稠密+稀疏） |
| 密钥 | `EMBEDDING_API_KEY`（`sk-ws-*`，写入 `.env`，未入库） |
| 批次 | 每请求 16 条（`EMBEDDING_BATCH_SIZE`；原生 API 单次上限 20） |
| 本地下载 | **无需下载权重**（区别于原方案本地 bge-m3 ~2.3GB） |

> 实测发现：用户提供的专属端点 `tws-p9vbybq8h7c7pbhx.cn-beijing.maas.aliyuncs.com` 仅 `GET /models` 可访问，**一切推理调用（chat/embedding）均返回 "Workspace endpoint is invalid"**；同一 `sk-ws` 密钥在百炼公共兼容端点 `dashscope.aliyuncs.com/compatible-mode/v1` 上 chat 与 embedding 均实测可用，故实际使用公共端点。

> 稀疏向量：DashScope **原生接口**（`output_type=dense&sparse`）一次返回稠密 1024 维 + 模型原生稀疏（词表 index + 权重，始终启用，无开关）；OpenAI 兼容端点不返回稀疏。

## 2.5 LLM（workspace 网关 ws-p9vbybq8h7c7pbhx）

| 项 | 值 |
| --- | --- |
| 服务 | 百炼 workspace 网关（OpenAI 兼容） |
| 端点 | `https://ws-p9vbybq8h7c7pbhx.cn-beijing.maas.aliyuncs.com/compatible-mode/v1`（`LLM_BASE_URL`/`LLM_LIGHT_BASE_URL`） |
| 主模型 | `qwen3.8-max`（`LLM_MODEL`；complex 路由 / 意图路由 / 查询重写 / HyDE） |
| 轻量模型 | `qwen3.7-flash`（`LLM_LIGHT_MODEL`；simple 问题路由） |
| 密钥 | `LLM_API_KEY` / `LLM_LIGHT_API_KEY`（`sk-ws-H.ERLIYHX.*`，写入 `.env`，未入库） |

> 2026-08-10 从阿里云套餐 token-plan 端点切换（其 1 周配额 2026-08-15 才重置）；ws 网关与 rerank 共用同一 workspace（`sk-ws-*` 体系），主/轻量模型实测 200 OK。套餐端点**不含嵌入模型**（嵌入仍走 dashscope 公共端点 sk-ws-* key），本网关同理，嵌入配置不变。
>
> 无密钥时自动降级 MockLLMClient（仅开发验证）。

## 3. Docker 镜像 / 容器 / 卷

| 项 | 值 |
| --- | --- |
| Compose 文件 | `c:\Users\admin\Desktop\work\show\newrag\infra\docker-compose.yml` |

| 镜像 | 版本 | 体积 | 用途 |
| --- | --- | --- | --- |
| qdrant/qdrant | v1.13.4 | 278 MB | 向量数据库 |
| redis | 7-alpine | 57.8 MB | 缓存/队列 |

| 容器 | 端口 | 状态 |
| --- | --- | --- |
| newrag-qdrant | 6333(HTTP) / 6334(gRPC) | Up |
| newrag-redis | 6379 | Up (healthy) |

| 卷 | 挂载目标 | 说明 |
| --- | --- | --- |
| infra_qdrant_data | /qdrant/storage | Qdrant 数据持久化 |
| infra_redis_data | /data | Redis 数据持久化 |

启动命令：`docker compose -f infra/docker-compose.yml up -d qdrant redis`

## 4. 数据与配置文件

| 项 | 路径 |
| --- | --- |
| 示例财报（生成） | `c:\Users\admin\Desktop\work\show\newrag\data\samples\sample_report.pdf`（9 页） |
| SQLite 登记库 | `c:\Users\admin\Desktop\work\show\newrag\data\registry.db` |
| 上传目录 | `c:\Users\admin\Desktop\work\show\newrag\data\uploads`（运行时生成） |
| 管线中间结果 | `c:\Users\admin\Desktop\work\show\newrag\data\pipeline\{doc_id}\`（01_layout/03_sections/04_chunks/05_vectors） |
| 财报抓取工具 | `c:\Users\admin\Desktop\work\show\newrag\tools\fetch_reports.py`（sec/sec-fin/巨潮 三路，输出 `data/raw_reports/`） |
| 原始财报（实测下载） | `c:\Users\admin\Desktop\work\show\newrag\data\raw_reports\sec\AAPL_10-K_2024-11-01.docx`、`data\raw_reports\sec\AAPL_financials.xlsx`、`data\raw_reports\cninfo\600000_2024年报.pdf` |
| 环境配置 | `c:\Users\admin\Desktop\work\show\newrag\.env`（本地，不入库）；模板见 `.env.example` |

## 5. 其他缓存

| 项 | 位置 | 说明 |
| --- | --- | --- |
| pip 缓存 | `%LOCALAPPDATA%\pip\Cache` | pip 下载缓存，重装提速 |
| tiktoken 编码文件 | 系统临时目录（`%TEMP%` 下 data-gym 缓存） | 首次 token 估算时下载 cl100k_base |

## 6. 已知注意事项

- `qdrant-client`(1.19.0) 与 Qdrant 服务端(1.13.4) 大版本不一致，已通过 `check_compatibility=False` 关闭强校验；如需消除差异，可把 `requirements.txt` 中 qdrant-client 锁到 `1.13.x`。
- `LLM_API_KEY` 未配置时，系统自动降级为 MockLLMClient（仅开发验证，输出模板回答，不产生真实推理）。
- 扫描件 OCR：仅使用 **PaddleOCR AI Studio**（ppocr）在线 API——`PPOCR_TOKEN`（存 .env，未入库），模型 `PP-StructureV3`，异步任务（提交 → 轮询 → 下载 JSONL → 按页 markdown 文本）。PDF 扫描页（文本提取率 <80%）与 png/jpg/jpeg 图片上传均走此路（图片需 `OCR_ENABLED=true`）。注意：ppocr 按整文档提交，非扫描页也会被重识别，耗时随页数增长。
- 嵌入后端已移除 `fastembed`（onnx 本地方案），改用百炼 API；本地备选仅剩 `flagembedding`（torch，惰性导入，未安装）。设置 `EMBEDDING_BACKEND=fastembed` 会直接报错。

## 7. 前端依赖（阶段三 Vue3）

| 项 | 路径 / 值 |
| --- | --- |
| 工程目录 | `c:\Users\admin\Desktop\work\show\newrag\frontend`（Vite 8 + Vue 3.5 + TypeScript） |
| Node / npm | 24.16.0 / 11.13.0（系统级） |
| 包管理器 | npm（官方源慢，安装走 `--registry=https://registry.npmmirror.com`） |

脚手架：`npm create vite@latest frontend -- --template vue-ts`

```powershell
cd frontend
npm install --registry=https://registry.npmmirror.com
npm install element-plus @element-plus/icons-vue vue-router@4 marked dompurify @types/dompurify --registry=https://registry.npmmirror.com
```

### 已安装关键依赖（package.json）

| 包 | 版本 | 用途 |
| --- | --- | --- |
| vue | 3.5.40 | 框架 |
| vue-router | 4.6.4 | 路由（/chat /documents /upload） |
| element-plus | 2.14.4 | 组件库（含暗色主题 css-vars） |
| @element-plus/icons-vue | 2.3.2 | SVG 图标（按钮/导航/状态） |
| marked | 18.0.9 | LLM 回答 Markdown 渲染（gfm+breaks） |
| dompurify | 3.4.13 | Markdown 渲染前 XSS 消毒 |
| @axe-core/playwright | 4.13.0 | Playwright 无障碍自动化检查 |
| eslint / eslint-plugin-vue | 9.39.5 / 10.10.0 | Vue / TypeScript 静态检查 |
| prettier | 3.9.6 | 前端格式检查 |

> 开发代理：`vite.config.ts` 将 `/api` 与 `/healthz` 代理到 `http://localhost:8000`，前端开发期无需跨域。
> SSE：EventSource 不支持 POST，前端用 `fetch + ReadableStream` 解析 `text/event-stream`（`src/api/sse.ts`）。
> 设计令牌：`src/styles/theme.css` 取自 `design-system/newrag/MASTER.md`（AI-Native 暗色，`--color-*` 系列）。

## 8. 变更记录

> 本文件随每次"下载 / 安装 / 卸载 / 配置变更"持续更新。

| 日期 | 变更 |
| --- | --- |
| 2026-08-06 | 初版：venv 与依赖、Docker 镜像/卷、数据目录、缓存说明 |
| 2026-08-07 | 嵌入切换为百炼 API（`qwen3.7-text-embedding`，1024 维），记录专属端点实测无效、改用公共端点 |
| 2026-08-07 | 移除 `fastembed` + `onnxruntime`（pip uninstall，requirements.txt 同步删除），清理残留目录 |
| 2026-08-07 | 配置 DeepSeek LLM 密钥（`deepseek-chat`），实测真实流式回答 |
| 2026-08-07 | 阶段二：安装 `jieba` 0.42.1（稀疏分词）；混合检索（dense+sparse+table → RRF k=60 → rerank）；意图路由/查询重写/多跳/HyDE（JSON mode）；多模型路由（simple→百炼 qwen3.5-flash，complex→DeepSeek） |
| 2026-08-07 | 阶段二注意：百炼 rerank 服务（`qwen3-vl-rerank`/`gte-rerank`）当前密钥返回 400/Access denied，已实现失败降级为 RRF 直出；开通后 `RERANK_BACKEND=api` 自动启用 |
| 2026-08-07 | **rerank 开通成功**：新密钥 `sk-ws-H.ERLREDY.*` + workspace 网关 `https://ws-p9vbybq8h7c7pbhx.cn-beijing.maas.aliyuncs.com` + 模型 `qwen3-rerank`，路径 `/api/v1/services/rerank/text-rerank/text-rerank`（配置项 `RERANK_API_PATH`）；实测引用返回真实相关性分（0.5~0.9），200 OK |
| 2026-08-07 | 财报抓取工具 `tools/fetch_reports.py`：安装 `beautifulsoup4` 4.15.0 + `yfinance` 1.5.2（requirements.txt 同步）；SEC/yahoo/巨潮 三路均已实测（SEC AAPL 10-K→DOCX、巨潮 600000 浦发银行年报→PDF 均可；yahoo 在本网络被 Yahoo 403 封锁，提示换用 sec 或代理） |
| 2026-08-07 | 接入 PaddleOCR AI Studio（ppocr）在线 OCR：`OCR_PROVIDER=ppocr` + `PPOCR_TOKEN`（模型 `PP-StructureV3`，异步任务 API）；PDF 扫描页与 png/jpg/jpeg 图片均可 OCR（图片需 `OCR_ENABLED=true`）；单页冒烟实测成功（浦发年报封面识别正常）；markdown/HTML 图片占位符自动剔除 |
| 2026-08-07 | 移除百度 OCR（`BaiduOcr`/`get_ocr`/`OCR_PROVIDER`/`OCR_API_KEY`/`OCR_SECRET_KEY`），OCR 仅保留 ppocr 一路 |
| 2026-08-07 | 新增 `sec-fin` 子命令：SEC EDGAR XBRL companyfacts 官方财务数据（无 key）→ 三大报表 Excel，替代被 Yahoo 403 封锁的 yfinance；实测 AAPL FY2021~FY2025（Revenues FY2025=$416.16B 正确），处理 ASC 606 概念别名（AAPL 用 RevenueFromContractWithCustomerExcludingAssessedTax / CostOfGoodsAndServicesSold / ResearchAndDevelopmentExpense） |
| 2026-08-07 | 移除 Yahoo 数据源：删除 `fetch_yahoo`/`yahoo` 子命令与 `yfinance` 依赖（requirements.txt 同步），财报数据仅保留 sec / sec-fin / 巨潮 三路 |
| 2026-08-07 | Small-to-Big 切分补齐（阶段一验收）：新增配置 `CHUNK_PARENT_TARGET_TOKENS=3072`（章节级父块 2~4K 目标）与 `TABLE_MAX_TOKENS=2048`（超长表格"摘要+分页"阈值）；正文相邻块保留 10% 重叠；父块 id 与叶子 `parent_id` 挂链一致；检索侧排除 `section` 父块、命中叶子按 `parent_id` 拉取章节上下文（`fetch_payloads`）。实测：浦发 2024 年报 4135 块（430 父块，叶子中位 176 token，正文相邻块重叠 87.5%）、AAPL 10-K 325 块（21 父块，95% 落在 2~4K token）；pytest 28 用例全过，已提交推送（a66cc53） |
| 2026-08-08 | **嵌入启用模型原生稀疏向量**：`ApiEmbedBackend` 改走 DashScope 原生接口（`output_type=dense&sparse` 一次返回稠密 1024 维 + 模型原生稀疏；base 自动从 compatible-mode 映射为 `/api/v1`；单次 `input.texts` 上限 20，内部按 `EMBEDDING_BATCH_SIZE` 分批）。稀疏路由由 jieba+IDF modifier 改为 qwen3.7-text-embedding 原生输出（词表 index + 语义权重，无 IDF；`text_type` 区分 document/query），`EMBEDDING_SPARSE_ENABLED` 控制开关，模型不可用时回退 jieba。同时修复 ingest 断点续跑 bug（`load_layout` 重复反序列化 `LayoutResult.from_dict`）。新增 6 个嵌入解析单测（pytest 34 过）。⚠️ **Qdrant `chunks` collection 已按新配置重建（旧 jieba 数据被清空）**，需重新上传文档重索引；且嵌入账户免费额度已耗尽（`AllocationQuota.FreeTierOnly`，dashscope 公共与 ws-gateway 均 403），充值或关闭"仅免费额度"模式后方可入库 |
| 2026-08-08 | 嵌入额度充值后恢复（e2e 实测：浦发 2024 年报 444 页 → 4135 块 → 模型原生稠密+稀疏入库 → 混合检索命中并附父块上下文，rerank 200 OK；验证后清理 e2e 数据）。另排查：用户新购阿里云套餐 key `sk-sp-*` + 专属端点 `token-plan.cn-beijing.maas.aliyuncs.com` **不含嵌入模型**（嵌入模型名均 "Model not exist"，仅含 qwen3.7-max/plus、qwen3.6-flash、glm-5.2、deepseek-v4-pro/flash、wan2.7-image 等），嵌入继续用 dashscope 公共端点 + sk-ws-* key |
| 2026-08-08 | **多模型路由切换至阿里云套餐**：`LLM_BASE_URL`/`LLM_LIGHT_BASE_URL` → `https://token-plan.cn-beijing.maas.aliyuncs.com/compatible-mode/v1`，`LLM_MODEL=deepseek-v4-flash-0731`（主，complex 路由/意图路由/查询重写/HyDE）、`LLM_LIGHT_MODEL=qwen3.7-plus`（轻量，simple 路由），密钥换套餐 `sk-sp-*`；实测两模型流式回答正常（200 OK） |
| 2026-08-08 | **清理 jieba 稀疏降级方案**：嵌入模型原生稀疏（`output_type=dense&sparse`）已确认可用，删除 `app/embed/sparse.py`（jieba BM25 风格兜底）、`tests/test_sparse.py`、requirements.txt 中 `jieba`（`pip uninstall jieba`）、`EMBEDDING_SPARSE_ENABLED` 配置项（config.py / .env.example / DESIGN.md）；ingest/search 移除回退逻辑（稀疏始终走模型原生，缺失时优雅跳过稀疏路），删除无调用方的 `search.retrieve()` 兼容入口；文档同步（README/PROMPT/DESIGN/INSTALL_RECORD） |
| 2026-08-08 | **阶段三前质量加固（代码变更，无新依赖）**：① 语义精切 `app/splitter/semantic.py`（结构优先、语义为辅：对超长散文叶子按嵌入相邻句相似度断点切分，低于 `SEMANTIC_SPLIT_SIM_THRESHOLD` 且 >= `CHUNK_MIN_TOKENS` 处切；mock/失败原样保留）；chunker 拆出 `build_leaves`/`build_parent_blocks`，ingest 阶段 3 顺序变为"结构叶子 → 语义精切 → 章节父块"；② 多轮会话记忆 `app/store/session.py`（Redis `session:{id}`，TTL 1 天，按 `SESSION_WINDOW` 裁剪；Redis 不可用静默降级无状态），`build_answer_messages` 支持历史注入；③ 接地校验 `app/generation/grounding.py`（回答数字/百分比回查知识块，剔除引用片段防误报），SSE 新增 `grounding` 事件（{checked, missing, citations}）；④ 置信度门控 `RETRIEVAL_MIN_SCORE`（仅 rerank 模式生效，低置信发 `warning` 事件）+ 复杂问题召回加深 `RETRIEVAL_DEPTH_SCALE`（放大各路 top_k 与 rerank 候选）；⑤ 检索评测 `backend/scripts/eval_retrieval.py` + `scripts/eval_golden.json`（NDCG@k 网格搜索：实测 k=30/60/100 结果相同——rerank 主导排序，保持 k=60；NDCG 低分源于 golden 集跨文档歧义）。新增配置项已同步 `.env.example`（`SEMANTIC_*`/`RETRIEVAL_MIN_SCORE`/`RETRIEVAL_DEPTH_SCALE`，默认值在 config.py，未改 .env）。pytest 37 过（新增 7 个测试） |
| 2026-08-08 | **陈旧文档防护 + 数据清洗（代码变更，无新依赖）**：① `documents.py` 上传前置防护——同 org 同 sha256 → 幂等返回 `status=duplicate`（failed 状态除外允许重试）；同名不同内容 → `UPLOAD_REPLACE_SAME_FILENAME=true` 时先 purge（Qdrant 点 + registry + pipeline 目录）再入库；delete 端点复用 `_purge_document`；② 年份过滤——检索侧 `_extract_year` 提取问题显式年份（`(19|20)\d{2}`），`search_dense/search_sparse/hybrid_search` 支持 `fiscal_year` payload 过滤，无该年份文档时自动回退全量并在 meta 标注 `year_fell_back`（实测 2023→回退 true / 2024→正常过滤）；③ 数据清洗 `app/parsers/clean.py`——NFKC 归一化（全角数字/逗号/百分号→半角）+ 页眉页脚去重（跨页高频短行、位于页首/页尾边缘区才剔除，`CLEAN_*` 系列配置），ingest 阶段 1.6（OCR 之后、章节树之前）幂等执行；新上传文档生效，存量文档不受影响。新配置已同步 `.env.example`（`UPLOAD_REPLACE_SAME_FILENAME`/`CLEAN_*`）。pytest 41 过（新增 4 个测试） |
| 2026-08-09 | **外部 API 限制缓解（代码变更，无新依赖）**：① 嵌入结果缓存 `app/store/cache.py`——按文本 sha256 缓存稠密+稀疏向量（`emb:{text_type}:{output_type}:{sha256}`，TTL `EMBED_CACHE_TTL`），dense 与 dense&sparse 分 key（稀疏结果不能通用）；② 语义答案缓存——无 session_id 单轮问答按问题向量余弦相似度 >= `SEMANTIC_CACHE_THRESHOLD` 整份回放（省 rerank + LLM 两段最贵调用），未命中收集事件流写入，桶按 `ANSWER_CACHE_MAX_ENTRIES` 裁剪、TTL `ANSWER_CACHE_TTL`；③ 并发限流——嵌入/LLM/rerank 各自信号量（`MAX_EMBED_CONCURRENCY`/`MAX_LLM_CONCURRENCY`/`MAX_RERANK_CONCURRENCY`，超限排队防 429）；④ 失败重试——嵌入/LLM/rerank 对 429/5xx 指数退避重试 3 次（0.5s/1s），重试耗尽抛错，rerank 失败仍降级 RRF 直出；⑤ 统一 Redis 连接 `app/store/redisx.py`（懒加载单例，Redis 不可用全部静默降级），session.py 复用。新配置已同步 `.env.example`（`SEMANTIC_CACHE_*`/`EMBED_CACHE_TTL`/`ANSWER_CACHE_*`/`MAX_*_CONCURRENCY`）。pytest 46 过（新增 5 个测试） |
| 2026-08-09 | **语义缓存二次校验 + 阻塞调用线程池化 + 公平信号量（代码变更，无新依赖）**：① 语义答案缓存命中后二次校验 `ANSWER_CACHE_MIN_OVERLAP=0.5`（`_char_overlap` 字符 2-gram Dice）——向量相似但问题文本重合度过低视为可疑不命中（实测换实体问句向量相似度仅 ~0.72 << 0.95 阈值，此校验为纯防御：防未来换嵌入模型/极端短句误命中）；② 阻塞调用线程池化——`answer.py` 的 `_search_plan`（嵌入 `embed_texts_with_sparse` + `hybrid_search`）与缓存查询嵌入改 `asyncio.to_thread`，事件循环不再被嵌入 API / Qdrant / rerank 同步阻塞占死（单 worker 并发问答不再串行化）；③ `app/generation/llm.py` 新增 `FairSemaphore`（FIFO 公平信号量）替换 `asyncio.Semaphore`——检索段并行化后多请求同时涌入 LLM 段，asyncio.Semaphore 非公平会把先到请求饿在队尾（实测并发 6 问个别请求被拖到 114s），FIFO 后恢复 ~17s。**并发实测（scripts/concurrency_probe.py，6 问同组对比）**：串行 129s vs 并发 58.6s（总耗时 = 最慢单问，事件循环不再阻塞），吞吐提升 ~2.2x。pytest 48 过（新增 2 个测试） |
| 2026-08-09 | **serena 排障修复（3 层）**：① **MCP 子进程 PATH 缺 uv** → `.mcp.json` serena 配置注入 `env.PATH`（含 `C:\Users\admin\.local\bin`）；② **uvx 解析依赖卡 PyPI 直连** → env 加 `UV_DEFAULT_INDEX=https://mirrors.aliyun.com/pypi/simple/` + `UV_HTTP_TIMEOUT=60`；③ **pyright 起不来的真正根因 = nodeenv 下载 node 失败**（nodejs.org 被墙，initialize 235s 超时）→ 用国内镜像预置 nodeenv：`uvx -p 3.13 --from pyright==1.1.403 python -m nodeenv --node=20.15.0 --mirror=https://npmmirror.com/mirrors/node/ C:\Users\admin\.cache\pyright-python\nodeenv`（nodejs.exe 硬链接创建失败无碍，`Scripts\node.exe` 就位即可）。**修复后验证：pyright 初始化 1.126s 完成、Found 60 source files、server ready**。注意 .venv/data/node_modules 已被项目 .gitignore 覆盖，pyright 自动排除大目录。|
| 2026-08-09 | **Agent Skills 安装（4 个）**：安装到项目根 `.agents/skills/`（Agent Skills 标准 SKILL.md 格式，供前端/UI 设计等使用）——① `frontend-design`（Anthropic 官方 anthropics/skills，SKILL.md+LICENSE）；② `web-design-guidelines`（Vercel Labs agent-skills，100+ 条 Web 界面规范）；③ `karpathy-guidelines`（multica-ai/andrej-karpathy-skills，Karpathy 四原则行为准则）；④ `ui-ux-pro-max`（nextlevelbuilder/ui-ux-pro-max-skill，67 风格/192 配色/字体库，含 data/stacks 支持 Vue/Tailwind 等 22 栈、references、scripts）。安装方式：GitHub 直连被墙 → ghfast.top 镜像稀疏克隆（`--depth 1 --filter=blob:none --sparse`）只取 skill 目录，未整仓克隆 |
| 2026-08-09 | **serena MCP 安装（工具，非 skill）**：按官方 Quick Start 安装——先装 `uv` 0.12.3（`irm https://astral.sh/uv/install.ps1 | iex` → `C:\Users\admin\.local\bin`），再 `uv tool install -p 3.13 serena-agent`（PyPI 直连慢 → `UV_DEFAULT_INDEX=https://mirrors.aliyun.com/pypi/simple/` 镜像装，清华 403 弃用；版本 1.6.1，含 serena/serena-agent/serena-hooks 三命令），`serena init` 初始化成功（全局配置 `C:\Users\admin\.serena\serena_config.yml`，LSP 后端，支持 40+ 语言）。**本项目 MCP 接入**：项目根已生成 `.mcp.json`（`serena start-mcp-server --context=ide --project <项目根>`，stdio） |
| 2026-08-09 | **codegraph MCP 安装（工具，非 skill）**：按官方安装——`npm i -g @colbymchenry/codegraph`（官方 registry 慢 → `--registry=https://registry.npmmirror.com`，版本 1.5.0，捆绑 Node 运行时无需 Node 编译）；`codegraph install` 已自动接入本机 **Codex CLI**（`~\.codex\config.toml` 写入 `[mcp_servers.codegraph] command=codegraph args=[serve,--mcp]`，Trae 不在自动支持列表，已在项目 `.mcp.json` 手动配置同款）；`codegraph init` 建图成功（743 文件 / 402 无法解析，12,924 节点、30,142 边，6.2s，索引在 `.codegraph/`，自动增量同步） |
| 2026-08-09 | **项目级 MCP 配置**：项目根新建 `.mcp.json`（标准格式），含 serena（stdio：serena.exe start-mcp-server --context=ide --project 项目根）与 codegraph（stdio：codegraph serve --mcp）两个 MCP server；Trae 端需在 MCP 设置中启用/添加（不同 IDE 读取方式不同，见会话说明）。注：GitHub 直连不稳定（443 reset），后续拉取 GitHub 一律走 `ghfast.top` 镜像前缀 |
| 2026-08-09 | **冗余与残留清理（代码变更，无新依赖）**：① 依赖分析——requirements.txt 全部依赖均有用（sqlalchemy→registry、bs4→fetch_reports、tiktoken→tokens、pdfplumber→layout）；② 降级方案复核——jieba/BM25/词法/`EMBEDDING_SPARSE_ENABLED` 已无任何残留（上轮已清），仅保留接口契约层"稀疏缺失→None"与 Redis/rerank 设计内降级，非临时 workaround；③ 死代码清理——删 `qdrant.count_docs`、`layout.export_pdf_text`、`parsers/metadata.py`（`guess_fiscal_meta` 无调用者，年份由上传表单显式提供）、`scripts/verify_cache.py`（临时 E2E 脚本，功能已被 test_cache_ratelimit 覆盖）；清理未使用 import（layout.io、structure.field、chunker.field、concurrency_probe.sys、ingest.guess_fiscal_meta）；删配置字段 `app_port`/`query_rewrite_enabled`/`hyde_max_tokens`（全库无引用）；`ingest.get_document_safe` 冗余 wrapper 简化；④ 修复 `prompts.build_answer_messages` **多轮历史注入失效 bug**（messages 含 history 已构建但 return 绕过，现返回含历史的消息序列）+ MockLLM 知识块正则（`【知识块 1】` 带编号匹配不上）；⑤ 配置/文档同步——README/DESIGN/PROMPT 更新（Redis 已启用、语义缓存已完成、pytest 48、tests 目录去掉 sparse、metadata 移除、flagembedding 移出"已移除"清单、DESIGN 配置清单加注"以 config.py/.env.example 为准"、Redis Keys 表更新为实际 key）；`.env.example` 删除 3 个废弃配置、补 `SESSION_WINDOW`/`PPOCR_POLL_INTERVAL`/`PPOCR_TIMEOUT`、`MAX_UPLOAD_MB` 与 config 统一为 50、`LLM_LIGHT_MODEL` 统一 `qwen3.7-plus`；`.gitignore` 补 `.codegraph/` 与 `.serena/`。pytest 回归全过 |
| 2026-08-09 | **表格专项加固（代码变更，无新依赖）**：① **分页块表头重复**——超大表格分页后每个分页块前置"表头 + `[本表共 N 行 × M 列，以下为分页明细]`"统计行（`chunker._table_header_block`），任意分页块独立可读；分页容量扣除表头 token（`capacity = table_max_tokens - 表头块 token`），加表头后每块仍不超 `TABLE_MAX_TOKENS=2048`；② **结构化表格元数据进 payload**——`Chunk` dataclass 新增可选字段 `table_headers`/`n_rows`/`n_cols`（`to_dict`/`from_dict` 同步序列化），`upsert_chunks` 对 `chunk_type="table"` 的点写入 Qdrant payload（供元数据过滤/展示）；文本块字段为 None。pytest 50 过（新增 2 个测试：分页块表头重复 + 元数据 / 小表元数据与序列化往返） |
| 2026-08-09 | **阶段三 Vue3 前端（新依赖：node_modules，见第 7 章）**：Vite 8 + Vue 3.5 + TS + Element Plus 2.14 + vue-router 4 + marked/dompurify。三页：① 问答页 `/chat`——`fetch+ReadableStream` 解析 SSE（POST），消费 meta（意图/复杂度/年份过滤/年份回退徽标）、citation（引用 chip，点击开抽屉显示章节/页码/分数）、warning（低置信告警）、token（流式渲染+光标）、grounding（数字校验展示）、error/done；多轮会话（uuid session_id，历史注入），会话与消息 localStorage 持久化；② 文档库 `/documents`——列表（文件名/状态/可见性/财年/知识块数/机构/上传时间/大小）、删除二次确认；③ 上传页 `/upload`——拖拽/点击选文件、机构/可见性/财年/财季表单、上传后任务进度轮询（parse→chunk→embed→index 阶段与 progress bar）、sha256 幂等重复提示。后端同步：`DocumentOut` 补 `size_bytes` 字段（前端展示文件大小）。vite dev 代理 `/api`→8000（CORS 已配 5173）。`npm run build`（vue-tsc 严格模式）通过；浏览器 E2E 实测：示例问答流式渲染+引用+grounding、多轮追问（归母净利润 452.57 亿、表格块引用 chip）、上传全管线（11 块入库+进度轮询+完成态）、删除确认与恢复，控制台无报错 |
| 2026-08-10 | **LLM 配置切换（token-plan → ws 网关）**：token-plan 套餐 1 周配额耗尽（reset 2026-08-15 07:28 UTC）。`LLM_BASE_URL`/`LLM_LIGHT_BASE_URL` → `https://ws-p9vbybq8h7c7pbhx.cn-beijing.maas.aliyuncs.com/compatible-mode/v1`（与 rerank 同一 workspace 网关），`LLM_MODEL=qwen3.8-max`（主）、`LLM_LIGHT_MODEL=qwen3.7-flash`（轻量），`LLM_API_KEY`/`LLM_LIGHT_API_KEY` → `sk-ws-H.ERLIYHX.*`（`.env` 已更新；token-plan 端 401 不接受 sk-ws key，ws 网关 200 OK 实测）。后端已重启、`/api/v1/chat` 端到端验证（meta+citations+token 流正常）。**评测集改造**：`offline_257`（全指标）→ 随机删 100 得 `offline_157_metric` + LLM 生成 120 非指标题（综述/比较/趋势/多跳/对抗，`offline_120_nonmetric_raw`）→ 指纹化合并 `offline_277.json`（277 题，相关块 = relevant_chunk_ids + relevant_fingerprints 双引用，语料重建免疫）。v9 评测（生产完整 RRF+rerank+relay，top_k=8）：总 NDCG@8=0.6016 / Rec@8=0.6104 / Rec@1=0.4595 / MRR=0.7122（v5 的 MRR=1.0 虚高被非指标题打破）；拆分——指标题 NDCG@8=0.8702（relay 保底）、非指标题 0.2500（比较 0.4489/趋势 0.2407/多跳 0.2041/对抗 0.1407/综述 0.1067），三路纯检索 0.16~0.26 不变。脚本：`scripts/gen_golden_nonmetric.py`（支持 `--resume` 增量）、`scripts/build_golden_237.py`（合并指纹化）；6 个 eval 脚本 GOLDEN_FILE → `offline_277.json`。另 `field_relay_boost` 0.5 → **0.35**（config.py，用户指定，后端已重启生效） |
| 2026-08-11 | **LLM 主力模型切换（ws 网关 qwen3.8-max → DeepSeek 官方 API deepseek-v4-flash）**：用户提供 DeepSeek 官方密钥 `sk-af63e27d*`，实测定位该密钥属于 `api.deepseek.com`（token-plan / 百炼公共 / ws 网关均 401；`deepseek-chat` 200 且响应模型名为 `deepseek-v4-flash`；官方模型名**不带** `-0731` 日期后缀，传 `deepseek-v4-flash-0731` 返回 400）。`.env` 更新：`LLM_BASE_URL=https://api.deepseek.com/v1`、`LLM_API_KEY=sk-af63e27d74b5421d8bdabf1db04bdce3`、`LLM_MODEL=deepseek-v4-flash`（仅主力，轻量仍 ws 网关 `qwen3.7-flash`）。端到端验证：`get_llm().chat()` 200 OK 返回"连通成功"。**注意：后端 uvicorn 需重启才生效**（get_settings/LLM 客户端进程内单例） |
| 2026-08-12 | **阶段四工程化：Celery 异步 + 增量索引 + OTel 可观测（新依赖：celery / opentelemetry-*）**：① **Celery 异步**——安装 `celery` 5.6.3（阿里云镜像），新增 `app/tasks/celery_app.py`（broker=Redis，JSON 序列化，`worker_process_init`+模块级 `init_db()` 保证 worker 内 SQLite 会话可用）+ `app/tasks/ingest_task.py`（`ingest.run` 任务显式绑定 celery_app）；`documents.py` 上传按 `TASK_BACKEND` 分派（`celery` 走 `ingest_document.delay` / 默认 `background` 保持 BackgroundTasks，无 worker 环境不受影响）；任务状态沿用 SQLite Task 表（跨进程共享，未引 result backend）。**worker 启动（Windows 无 prefork，用 solo 池）**：`cd backend; .\.venv\Scripts\celery.exe -A app.tasks.celery_app worker -P solo --loglevel=info`。端到端验证通过（提交→worker 执行→SQLite 状态 success，2 块入库）。② **增量索引**——新增 `scripts/index_maintenance.py` 四命令：`stats`（Qdrant 点数 vs registry 块数汇总）/`check`（对账：孤儿点/缺块/残留点，异常退出码 1；当前 16 indexed 文档全量一致）/`restore --doc`（从 pipeline stage 重入向量，无需源文件/不调嵌入 API）/`reindex --doc --file`（清 stage+删向量+全量重跑，切分/嵌入参数变更后用）。③ **OTel 可观测**——安装 `opentelemetry-sdk/api/instrumentation-fastapi`，新增 `app/core/otel.py`（TracerProvider + ConsoleSpanExporter + MeterProvider + ConsoleMetricReader 本地导出，`OTEL_ENABLED` 控制）+ `app/core/metrics.py`（外部 API 调用计数/失败/延迟直方图）；`main.py` lifespan 启用 FastAPI 自动 instrumentation；手动 span 埋点——`answer.py` 检索段 `answer.search` + 生成段 `answer.generate`、`ingest.py` 全阶段 span（`stage_*_s` attribute）、reranker/llm/embedder 外部调用指标（`api.calls/api.errors/api.duration`）。pytest 141 过，无回归。新配置：`TASK_BACKEND`（config.py 默认 background）、`OTEL_ENABLED`（默认 false） |
| 2026-08-12 | **P0 性能配置收敛（无新依赖）**：新增 `EMBED_DOCUMENT_CACHE_TTL=0`，默认不缓存入库侧 `text_type=document` 向量，保留查询向量缓存；新增 `/livez` 和 5 秒依赖检查缓存；新增 `/api/v1/config/public` 向前端公开上传限制、扩展名与财年范围。前端上传限制从硬编码 200MB 改为服务端动态 50MB（接口不可用时回退 50MB）。 |
| 2026-08-12 | **前端无障碍门禁**：安装 `@axe-core/playwright` 4.13.0，用于 375px / 768px / 1440px 页面的 axe 自动化检查；`npm audit` 0 漏洞。 |
| 2026-08-12 | **OTLP + 完整容器化**：安装 `opentelemetry-exporter-otlp-proto-http` 1.44.0；新增 `OTEL_EXPORTER` / `OTEL_OTLP_ENDPOINT` / `OTEL_SAMPLE_RATIO` 和 `REDIS_CACHE_URL`（空值回退 `REDIS_URL`）。新增非 root API/worker/frontend Dockerfile、Nginx SSE 反代和完整 Compose；缓存 Redis 限制 384MB + `allkeys-lru`，broker Redis 使用 `noeviction`。 |
| 2026-08-12 | **代码质量门禁**：安装 Ruff 0.12.11、ESLint 9.39.5、eslint-plugin-vue 10.10.0、`@vue/eslint-config-typescript` 14.9.0 和 Prettier 3.9.6；安装 `httpx2` 2.10.0 消除 Starlette TestClient 兼容警告。新增 `backend/pyproject.toml` / `requirements-dev.txt` 及前端 `lint` / `format:check` 命令，先约束新增与修改文件。 |
