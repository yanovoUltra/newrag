# 多模态财报深度分析 RAG 系统 — 设计文档

> 依据 [PROMPT.md](./PROMPT.md) 编制。本文档为编码前的设计与实施计划，经确认后按阶段实施。

## 1. 环境实测（2026-08-06）

| 项 | 版本 | 备注 |
| --- | --- | --- |
| Python | 3.13.9 | 满足 ≥3.10；嵌入走百炼 API（无本地权重依赖） |
| pip | 26.1.2 | |
| Node / npm | 24.16.0 / 11.13.0 | 前端构建 OK |
| Docker / Compose | 29.6.2 / v5.3.1 | Qdrant / Redis / Phoenix 容器化 |
| PowerShell | 5.x | 已放开执行策略（RemoteSigned） |

## 2. 总体架构

```text
┌─────────────── Vue3 + Element Plus + TS 前端（阶段三）───────────────┐
│  上传页(拖拽上传+任务状态轮询)   问答页(SSE流式+引用回跳)      │
└───────────────────────────┬────────────────────────────────┘
                            │ REST + SSE(text/event-stream)
                    ┌───────▼────────┐
                    │  FastAPI 网关   │  /api/v1/*
                    └───────┬────────┘
          ┌─────────────────┼──────────────────┐
          ▼                 ▼                  ▼
   [离线管线]          [在线检索与生成]     [SQLite 文档登记]
   解析→切分→向量→入库  多路召回→RRF→Rerank  doc/task 状态
   (BackgroundTasks,    →父块上下文扩展
   每阶段落盘可续跑)      →意图路由→LLM→SSE
          │                 │
          ▼                 ▼
    Qdrant(稠密+稀疏)   Redis(缓存/会话，已启用)
          │                 │
          └──────── OTEL ───┴──▶ Phoenix(阶段四)
```

> 阶段四将离线任务迁移 Celery；Redis 会话与语义缓存已落地启用（2026-08-08）。

## 3. 目录结构

```text
newrag/
├── backend/
│   ├── app/
│   │   ├── main.py                # FastAPI 入口、lifespan、CORS、路由注册（/api/v1/*）
│   │   ├── core/
│   │   │   ├── config.py          # pydantic-settings 读取 .env（全部配置项）
│   │   │   └── logging.py         # 结构化日志
│   │   ├── api/v1/
│   │   │   ├── documents.py       # 上传/列表/详情/删除
│   │   │   ├── tasks.py           # 任务状态轮询
│   │   │   └── chat.py            # SSE 流式问答
│   │   ├── models/entities.py     # SQLAlchemy：Document / Task（登记库）
│   │   ├── schemas/               # Pydantic DTO
│   │   ├── parsers/
│   │   │   ├── base.py            # LayoutResult/ParsedPage/ParsedTable + 分层调度
│   │   │   ├── layout.py          # PyMuPDF/PDFPlumber：文本+表格（bbox 掩码去重）
│   │   │   ├── ocr.py             # PaddleOCR AI Studio（ppocr）：异步任务→JSONL→markdown
│   │   │   ├── structure.py       # 章节树构建（标题层级推断 + section_path）
│   │   │   └── clean.py           # 数据清洗（NFKC 归一化 + 页眉页脚去重）
│   │   ├── splitter/
│   │   │   ├── chunker.py         # Small-to-Big：叶子 128~256 + 章节父块 2~4K + 10% 重叠 + 表格摘要分页（分页块重复表头）
│   │   │   └── tokens.py          # token 估算（tiktoken cl100k_base / CJK 启发式）+ 硬切
│   │   ├── embed/
│   │   │   └── embedder.py        # DashScope 原生 API 嵌入（qwen3.7-text-embedding，稠密+模型原生稀疏）
│   │   ├── store/
│   │   │   ├── qdrant.py          # collection 管理 + upsert/query + payload 过滤 + fetch_payloads
│   │   │   └── registry.py        # SQLite 登记 + 串行持久化中间结果落盘
│   │   ├── retrieval/
│   │   │   ├── search.py          # 混合检索：多路召回→RRF→rerank→权限校验→父块上下文扩展
│   │   │   ├── router.py          # 意图路由 + 查询重写 + 多跳拆分 + HyDE（JSON mode）
│   │   │   ├── reranker.py        # 百炼 workspace 网关 API Rerank（失败降级）
│   │   │   └── rrf.py             # RRF k=60 融合
│   │   ├── generation/
│   │   │   ├── prompts.py         # 角色+任务+知识+约束 模板（含章节上下文混入）
│   │   │   └── llm.py             # OpenAI 兼容客户端（主/轻量多模型路由，当前走阿里云套餐）
│   │   └── pipelines/
│   │       ├── ingest.py          # 解析→(OCR)→章节树→切分→向量化→入库 串行落盘
│   │       └── answer.py          # 路由→检索→知识块组装→多模型流式生成（SSE 事件协议）
│   ├── tests/                     # pytest：chunker/rrf/router/embedder/cache_ratelimit/new_features/permission/api_flow/ocr
│   └── requirements.txt
├── infra/docker-compose.yml       # qdrant + redis
├── scripts/gen_sample_report.py   # 生成示例财报 PDF（9 页）
├── tools/fetch_reports.py         # 财报抓取：sec / sec-fin(XBRL) / 巨潮 三路
├── .env.example
├── PROMPT.md / DESIGN.md / README.md / INSTALL_RECORD.md
└── data/                          # 运行时数据（gitignore）：uploads / pipeline / raw_reports / registry.db
```

> 与早期设计相比的实际调整：`frontend/`（阶段三）、`memory/`、`tasks/celery`、`core/otel.py`、`splitter/section_tree.py + tables.py`（合并入 chunker.py）尚未落地；检索/路由模块合并为 `retrieval/search.py + router.py + reranker.py + rrf.py`。

## 4. 数据模型

### 4.1 SQLite 登记库（`data/registry.db`）

| 表 | 关键字段 | 说明 |
| --- | --- | --- |
| documents | id, filename, sha256, size_bytes, file_type(pdf/docx/xlsx/png/jpg), status(pending/parsing/chunking/embedding/indexed/failed), org_id, visibility(public/internal/restricted), fiscal_year, fiscal_quarter, chunk_count, error, created_at, updated_at | 文档主表，sha256 用于增量索引版本检测 |
| tasks | id, type(ingest/delete), doc_id, status(running/success/failed), stage(queued/parse/chunk/embed/index), progress, message, created_at | 任务状态（供前端轮询） |

> 章节树不单独建表：切分结果 `04_chunks.json` 已含 `section_path / parent_id`，可随时重建。
> 串行持久化：`data/pipeline/{doc_id}/` 下按阶段落盘 `01_layout.json / 02_ocr.json / 03_sections.json / 04_chunks.json / 05_vectors.json`，阶段完成即写 status，支持断点续跑与回溯。

### 4.2 Qdrant Collection：`chunks`

```text
vectors:        { "dense": {size:1024, distance:Cosine} }
sparse_vectors: { "sparse": {} }                    # 嵌入模型原生稀疏（词表 index + 语义权重，无 IDF）
payload(每点):
  chunk_id, doc_id, doc_name,
  page(int), section_path(str), chunk_type(text|table|section),
  org_id(str), visibility(public|internal|restricted),
  fiscal_year(int), fiscal_quarter(int),          # 文档级元数据（upsert 时写入）
  token_count(int), parent_id(str|null), content(str)
  table_headers(list[str]), n_rows(int), n_cols(int), # 表格块结构化元数据（chunk_type=table）
payload 索引: org_id(keyword) / visibility(keyword) / chunk_type / doc_id
```

- 稠密 + 稀疏同 collection，权限字段进 payload → 查询强制 `must` 过滤（org_id + visibility 可见性集合），返回后二次校验。
- **Small-to-Big 检索消费**：`section` 父块不进召回候选（`must_not` 过滤）；命中叶子按 `parent_id` 经 `fetch_payloads` 批量回查所属章节父块，作为上下文附加（`search._attach_parent_context`）。
- 表格作为不可分割单元独立成块；超长表格（> `TABLE_MAX_TOKENS`=2048）切"摘要块（表头+前 2 行+规模统计）+ 分页块"，分页块重复表头与规模统计行（`_table_header_block`），任意分页块独立可读；表格块 payload 携带 `table_headers/n_rows/n_cols` 结构化元数据。
- 正文相邻叶子块保留尾部 10% 重叠（`CHUNK_TARGET_TOKENS`=200 的 10%），消解块边界截断。

### 4.3 Redis Keys

| Key | 结构 | 用途 |
| --- | --- | --- |
| `task:{task_id}` | Hash：status/progress/stage/error | 任务状态（轮询主来源） |
| `session:{id}` | List：最近 N 轮（默认10） | 会话短期记忆（已启用，TTL 1 天） |
| `answer_cache:{org_id}:{visibility}` | List：缓存答案条目（q_norm/q_vec/events） | 语义答案缓存（已启用：问题向量相似度 ≥ 阈值 + q_norm 字符二次校验，整份回放） |
| `emb:{text_type}:{output_type}:{sha256}` | String：稠密+稀疏 JSON | 嵌入结果缓存（已启用，TTL 1 天，dense 与 dense&sparse 分 key） |
| `doc:{doc_id}:hash` | String：sha256 | 增量索引版本检测（sha256 已存 SQLite documents 表，Redis 槽位为规划） |

> 任务状态存 SQLite `tasks` 表（registry.py）；Redis 已用于会话（`session:{id}`）与缓存（`emb:*` / `answer_cache:*`）。

## 5. 依赖清单（requirements.txt 分组）

```text
# Web 框架
fastapi  uvicorn[standard]  python-multipart  pydantic  pydantic-settings  sse-starlette

# 存储
qdrant-client  redis  sqlalchemy

# 解析
pymupdf  pdfplumber  python-docx  openpyxl

# 检索（阶段二）
tiktoken     # token 估算（cl100k_base）
beautifulsoup4  # 财报抓取工具（SEC HTML 清洗）

# LLM / 嵌入（OpenAI 兼容 SDK：DeepSeek / 百炼通用）
openai  httpx

# 测试
pytest  pytest-asyncio
```

> 已移除：`fastembed / onnxruntime`（嵌入改用百炼 API，无本地权重）、`yfinance`（Yahoo 403 封锁，改用 SEC XBRL）、`jieba`（模型原生稀疏已启用，无兜底需求）、`celery / rank-bm25 / otel / ragas`（Phase 4/5 引入）。`flagembedding` 保留为未安装的本地备选（torch 惰性导入，稀疏返回 None）。

## 6. API 设计（`/api/v1`）

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/documents` | multipart 上传（类型/大小校验），返回 `{task_id, doc_id}`，异步解析 |
| GET | `/documents` | 文档列表（分页） |
| GET | `/documents/{doc_id}` | 文档详情 + 解析状态 + 分块统计 |
| DELETE | `/documents/{doc_id}` | 删库 + 删向量（Phase 4 原子"删旧+写新"） |
| GET | `/tasks/{task_id}` | 任务状态轮询（含 stage/progress/error） |
| POST | `/chat` | body: `{question, session_id, org_id}` → **SSE 流**（答案 token + 引用事件） |
| GET | `/sessions/{session_id}` | 会话历史（阶段二预留，未实现） |
| GET | `/healthz` | 依赖健康检查（qdrant/redis/llm） |

**SSE 事件协议**（`POST /chat` 实测字段）：
```text
event: meta      data: {"org_id":..., "top_k":..., "intent":..., "complexity":..., "needs_hyde":...}
event: citation  data: {"doc_id":..., "doc_name":..., "section_path":..., "page":..., "chunk_type":..., "score":...}
event: token     data: {"delta": "..."}
event: done      data: {"usage": {...}}
event: error     data: {"message": "..."}   # LLM 流式失败时
```

## 7. 配置清单（.env）

```env
> 注：以下为部署期示例，完整配置项以 config.py 与 .env.example 为准。
# 服务
APP_ENV=development
CORS_ORIGINS=http://localhost:5173

# 存储
QDRANT_URL=http://localhost:6333
QDRANT_COLLECTION=chunks
REDIS_URL=redis://localhost:6379

# 嵌入（百炼 DashScope 原生 API：一次返回稠密 + 模型原生稀疏；flagembedding/mock 为备选）
EMBEDDING_MODEL=qwen3.7-text-embedding     # 稠密 1024 维 + 原生稀疏
EMBEDDING_BACKEND=api                      # api | flagembedding | mock
EMBEDDING_API_BASE=https://dashscope.aliyuncs.com/compatible-mode/v1  # 运行时自动映射为原生 /api/v1
EMBEDDING_API_KEY=
EMBEDDING_BATCH_SIZE=16

# LLM（OpenAI 兼容；阿里云套餐专属端点 token-plan，多模型路由；也可用 DeepSeek 官方端点）
LLM_BASE_URL=https://token-plan.cn-beijing.maas.aliyuncs.com/compatible-mode/v1
LLM_API_KEY=                              # 套餐 key（sk-sp-*）
LLM_MODEL=deepseek-v4-flash-0731          # 主模型（complex 路由 / 意图路由 / 查询重写 / HyDE）
LLM_LIGHT_BASE_URL=https://token-plan.cn-beijing.maas.aliyuncs.com/compatible-mode/v1
LLM_LIGHT_MODEL=qwen3.7-plus              # 轻量模型（simple 问题路由）

# OCR（PaddleOCR AI Studio 在线；扫描件提取率<80% 按需触发；图片需 OCR_ENABLED=true）
OCR_ENABLED=false
PPOCR_TOKEN=
PPOCR_JOB_URL=https://paddleocr.aistudio-app.com/api/v2/ocr/jobs
PPOCR_MODEL=PP-StructureV3

# 重排序（api=百炼 workspace 网关 | none=RRF 直出）
RERANK_BACKEND=none
RERANK_API_BASE=https://dashscope.aliyuncs.com
RERANK_API_KEY=
RERANK_MODEL=qwen3-rerank
RERANK_API_PATH=/api/v1/services/rerank/text-rerank/text-rerank
RERANK_CANDIDATES=50

# 检索（阶段二混合检索）
RECALL_DENSE_TOP_K=50
RECALL_SPARSE_TOP_K=50
RECALL_TABLE_TOP_K=20
RRF_K=60
RETRIEVAL_TOP_K=8

# 路由 / 查询重写 / HyDE（阶段二）
INTENT_ROUTING_ENABLED=true
QUERY_REWRITE_ENABLED=true
HYDE_ENABLED=true
HYDE_MAX_TOKENS=256

# 切分（Small-to-Big）
CHUNK_MIN_TOKENS=128
CHUNK_TARGET_TOKENS=200
CHUNK_MAX_TOKENS=256
CHUNK_PARENT_TARGET_TOKENS=3072          # 章节级父块目标（2~4K 区间中值）
TABLE_MAX_TOKENS=2048                     # 超过则表格"摘要+分页"

# 会话 / 缓存（阶段二/四）
SESSION_WINDOW=10
SEMANTIC_CACHE_THRESHOLD=0.95

# 上传
MAX_UPLOAD_MB=50
UPLOAD_DIR=./data/uploads
PIPELINE_DIR=./data/pipeline
REGISTRY_DB=./data/registry.db
```

> 密钥只写 `.env`（gitignore），模板见 `.env.example`。

## 8. 实施计划（按阶段交付，每阶段验证可运行）

### 阶段一：最小闭环（离线单路 + 基础问答）✅
- 交付：FastAPI 骨架、SQLite 登记、上传接口（校验）、PDF/DOCX/XLSX/图片解析（版式层）、章节树、Small-to-Big 切分、百炼稠密向量入库、单路检索（dense）+ 权限 payload 过滤、`POST /api/v1/chat` SSE 流式（基础 Prompt + 引用标注）、`docker-compose.yml`（qdrant/redis）、`.env.example`。
- 异步：FastAPI `BackgroundTasks` 跑解析（Phase 4 迁 Celery）。
- 验证：上传示例财报 → 状态轮询到 indexed → 提问 → SSE 输出含引用；`GET /healthz` 全绿；AAPL 10-K / 浦发 2024 年报（444 页）实测解析入库成功。

### 阶段二：检索增强 ✅
- 交付：模型原生稀疏向量召回（qwen3.7-text-embedding，`output_type=dense&sparse`，document/query 双 text_type）、RRF 融合、意图路由（JSON mode）、查询重写、多跳子查询、HyDE、Reranker（百炼 workspace 网关 API，可切 none 降级）、多模型路由（simple→套餐 qwen3.7-plus，complex→套餐 deepseek-v4-flash-0731）、**Small-to-Big 检索消费**（父块排除 + parent_id 上下文扩展）。
- 验证：混合检索全链路测试通过；rerank 引用返回真实相关性分（0.5~0.9）；NDCG 提升待阶段五评估补测。

### 阶段三：前端
- 交付：Vue3 + Vite + Element Plus + TS；上传页（拖拽 + 任务进度轮询）、问答页（SSE 流式渲染 + 引用点击回跳）、文档列表页。
- 验证：浏览器全流程联调；引用点击定位到文档章节/页码。

### 阶段四：工程化
- 交付：Celery 任务链（含断点续跑）、增量索引（sha256 版本检测 + 删旧写新 + 每日对账）、语义缓存（>0.95）、会话短期记忆（Redis 注入 Prompt）、OTel→Phoenix 全链路、上传安全加固。
- 验证：Phoenix 可查完整链路；重复上传命中增量更新；权限负例检索为空。

### 阶段五：评估与收尾
- 交付：QA 数据集（300~500 条：单跳/多跳/表格/权限负例）、RAGAS 离线跑分、检索指标（Recall@10/MRR@10/NDCG@10）+ 消融表、README 完善（安装/启动/演示）。
- 验证：faithfulness ≥0.85、answer_relevancy ≥0.85、SSE 首 token <3s、权限负例全过。

## 9. 风险与缓解

| 风险 | 影响 | 缓解 |
| --- | --- | --- |
| 百炼嵌入 API 成本 / 网络依赖 | 批量入库受网络抖动影响 | `EMBEDDING_BATCH_SIZE=16` 分批；失败重试；本地 flagembedding 兜底（未启用） |
| DashScope 稀疏向量仅原生 API 支持 | OpenAI 兼容端点拿不到稀疏 | 嵌入统一走原生 /api/v1（`output_type=dense&sparse`，base 自动映射，已落地） |
| reranker 密钥 / 端点不可用 | 精排失败 | 失败自动降级 RRF 直出（已落地）；公共端点该密钥 400，须用 workspace 网关 `ws-*` 域名 |
| ppocr 整文档异步任务耗时 | 扫描件处理慢 | 仅在文本提取率 <80% 时触发；按页取非扫描页文本 |
| Yahoo 数据源在本网络 403 | 美股报表获取受阻 | 弃用 yfinance，改用 SEC EDGAR XBRL companyfacts（无 key，已实测） |
| 模型稀疏权重叠加 IDF 不确定 | 稀疏打分变形 | 稀疏向量不再叠加 Qdrant IDF modifier（模型权重已含语义重要度）；消融对比待阶段五 |
| 前端 SSE POST | EventSource 不支持 POST | 用 `fetch + ReadableStream` 解析 `text/event-stream` |
| 大表格分页导致块内语义割裂 | 表格检索精度下降 | 摘要块含表头 + 规模统计；表格块共享章节父块上下文 |

## 10. 测试与评估方案

- **单元测试**：切分（token 区间/重叠率/父块挂链/表格摘要分页/分页块表头重复/表格元数据）、RRF 融合、意图路由、稀疏向量、嵌入响应解析（原生 dense&sparse）、缓存/限流、语义切分、会话、数据清洗、年份过滤、陈旧文档防护、Prompt 模板渲染（当前 50 个用例全过）。
- **集成测试**：上传→解析→入库→问答 全链路（pytest + ASGI TestClient + 本地 qdrant/redis）。
- **权限负例**：orgA 检索只含 orgA 权限数据；越权问题返回空。
- **评估脚本**：`scripts/eval/` 生成 QA 集 → 跑 RAGAS 四指标 + 检索三指标 + 消融（dense-only / sparse-only / hybrid / hybrid+rerank），结果输出 CSV 与报告（阶段五）。

---

*确认本设计后开始阶段一编码。*
