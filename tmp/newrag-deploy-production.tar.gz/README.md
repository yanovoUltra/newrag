# 多模态财报深度分析 RAG 系统（newrag）

> 一个基于 RAG 的多模态财报深度分析系统：离线解析（PDF / Word / Excel / 扫描件）→ Small-to-Big 语义切分 → 混合检索（稠密 + 稀疏 + 表格）→ 流式问答，支持权限隔离与引用溯源。

[![Python](https://img.shields.io/badge/Python-3.13-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.141-teal.svg)](https://fastapi.tiangolo.com/)
[![Qdrant](https://img.shields.io/badge/Qdrant-1.13-red.svg)](https://qdrant.tech/)
[![License](https://img.shields.io/badge/License-MIT-orange.svg)](LICENSE)

## 目录

- [项目概述](#项目概述)
- [功能特性](#功能特性)
- [架构设计](#架构设计)
- [技术栈](#技术栈)
- [安装指南](#安装指南)
- [使用说明](#使用说明)
- [配置方法](#配置方法)
- [目录结构](#目录结构)
- [阶段状态](#阶段状态)
- [常见问题](#常见问题)
- [许可证信息](#许可证信息)

***

## 项目概述

本项目构建一套面向财报深度分析的 RAG 系统，实现从文档上传到流式问答的全链路能力：

- **离线解析**：PyMuPDF / PDFPlumber 提取文本与表格，扫描件按需走 PaddleOCR AI Studio（ppocr）在线 OCR；解析 → 章节树 → 切分 → 向量化 → 入库逐阶段落盘，可断点续跑。
- **语义感知切分**：Small-to-Big 多粒度分块——叶子 chunk 128\~256 token（目标 200）+ 章节级父块 2\~4K token（目标 3072）+ 相邻块 10% 重叠；表格作为不可分割单元，超长表格采用"摘要 + 分页"，分页块重复表头保证独立可读。
- **在线检索**：Dense top-50 + 稀疏（模型原生，`text_type=query`）top-50 + 表格 top-20 多路召回 → RRF(k=60) 融合 → 可选 Reranker 精排 → 命中叶子按 `parent_id` 扩展章节上下文。
- **流式生成**：意图路由 / 查询重写 / 多跳拆分 / HyDE（JSON mode）+ 多模型路由（简单问题走轻量模型），SSE 流式输出并标注引用来源。

### 核心能力

| 能力    | 说明                                                |
| ----- | ------------------------------------------------- |
| 多格式解析 | PDF / DOCX / XLSX / 图片，扫描件 ppocr 按需触发（文本提取率 <80%） |
| 语义切分  | 章节树 + Small-to-Big 多粒度分块，保留表格完整性与元数据              |
| 混合检索  | 稠密 + 稀疏 + 表格多路召回，RRF 融合 + Reranker 精排             |
| 流式问答  | SSE 流式输出，引用溯源 \[文档-章节-页码]，权限二次校验                  |

### 适用场景

- 年报 / 财报结构化分析（SEC 10-K、A 股年报等）
- 企业内部文档知识库问答
- 多文档对比与指标抽取

***

## 功能特性

- **多格式文档解析**：支持 PDF / Word / Excel / 图片；扫描件自动触发 ppocr（PaddleOCR AI Studio，PP-StructureV3）。
- **语义感知切分**：基于章节树的多粒度分块——叶子 128\~256 token、章节级父块 2\~4K token、相邻块 10% 重叠、超长表格"摘要 + 分页"（分页块重复表头），每个 chunk 携带 `doc_id / page / section_path / chunk_type / org_id / visibility / parent_id`（财报期 `fiscal_year/fiscal_quarter` 为文档级 payload 字段；表格块另带 `table_headers / n_rows / n_cols` 结构化元数据）。
- **混合检索**：稠密向量 + 模型原生稀疏向量（qwen3.7-text-embedding `output_type=dense&sparse`）+ 表格路多路召回，RRF 融合，命中后按 `parent_id` 扩展章节级上下文。
- **重排序精排**：接入百炼 workspace 网关 API Rerank（`qwen3-rerank`），失败自动降级 RRF 直出。
- **引用溯源**：回答自动标注来源 \[文档-章节-页码]，每个结论可定位。
- **权限隔离**：payload 级过滤（org\_id + visibility），检索后二次校验，防止越权召回。
- **多模型路由**：简单问题走轻量模型（阿里云套餐 qwen3.7-plus），复杂问题走主模型（套餐 deepseek-v4-flash-0731）。
- **任务状态轮询**：解析任务 stage/progress 全程可查（parse → chunk → embed → index）。
- **串行持久化**：解析中间结果逐阶段落盘，支持断点续跑与问题回溯。
- **API 认证鉴权**：可选 HMAC 签名 + 时间戳窗口 + nonce 防重放（`AuthMiddleware` 拦截链，密钥仅存 `.env`，不打日志）。
- **超时控制**：SSE 会话级 `asyncio.timeout` + 入库任务级协作式 deadline，超时安全中止。
- **失败补偿**：入库异常统一回滚 Qdrant 向量点防孤儿，保留阶段文件供断点续跑。
- **Agent 安全防线**：Prompt 注入检测（正则 + 可配关键词）、重复提问循环检测，均不阻断正常问答。
- **问答记录持久化**：`chat_records` 落库（离线复评 / RAGAS 数据源），失败不影响回答。
- **数据清洗**：页眉页脚去重 + 页码行剔除 + NFKC 归一化；PDF 双栏版式自动检测重组阅读顺序。
- **接地校验**：回答数字语义级回查知识块（支持跨单位等价，如 `17.07亿元`≈`170,748万元`）。
- **嵌入并发优化**：修复 `ApiEmbedBackend._call` 串行逐批调用导致并发信号量从未生效的 bug，改为 `ThreadPoolExecutor` 并发发送各批（并发上限 `max_embed_concurrency`=8，信号量兜底防 429）。实测吞吐 3.1 → 9.9 texts/s（约 3.2 倍），批量入库耗时显著下降。
- **文档侧 IDF 重写（稀疏路治本）**：入库时对稀疏 index 乘离线统计的 IDF，压低高频结构词、抬升判别词——修复稀疏路"同词不同义"噪声。**增益与问题类型相关**：对"公司名+年份"主导的实体型查询（营收）为正收益（NDCG@8 +4.6%）；但对靠"归属于上市公司股东的净利润"等通用表头标签定位答点行的指标型查询，IDF 把高频标签降权反而损害召回。扩充 golden 至 18 题后的全集净收益为负（详见 `backend/scripts/ablation_report.md` §5）。
- **结构块降权**：识别"财务表头/页眉/版式说明"类独立块并打 `is_structural` 标，检索时置后降权（实测占比仅 0.45%，对召回无影响；原 off/exclude 多模式已移除，仅保留降权）。
- **版本控制**：同名替换旧版归档（`archived` 留档可追溯），`list` 默认隐藏归档、可 `include_archived` 查看。
- **评测体系**：检索消融网格（dense/sparse/table/生产完整 + rerank）、RAGAS 指标（忠实度/相关性/上下文精确率）离线复评，结果落 `eval_results` 表。注：BM25 词法基线与稠密/稀疏加权配比实验已移除（结论已固化于 `ablation_report.md`：BM25 无贡献、加权配比无意义）。

***

## 架构设计

```text
┌─────────────── Vue3 + Element Plus + TS 前端（阶段三）───────────────┐
│  上传页(拖拽上传+任务状态轮询)     问答页(SSE流式+引用回跳)             │
└───────────────────────────┬────────────────────────────────────────┘
                            │ REST + SSE(text/event-stream)
                    ┌───────▼────────┐
                    │  FastAPI 网关   │  /api/v1/*
                    └───────┬────────┘
          ┌─────────────────┼──────────────────┐
          ▼                 ▼                  ▼
   [离线管线]          [在线检索与生成]     [SQLite 文档登记]
   解析→切分→向量→入库  多路召回→RRF→Rerank  doc/task 状态
   (BackgroundTasks,    →父块上下文扩展
   每阶段落盘可续跑)      →意图路由→LLM→SSE
          │                 │
          ▼                 ▼
    Qdrant(稠密+稀疏)   Redis(缓存/会话，已启用)
```

数据流：上传文档 → 解析（版式/OCR/章节树）→ Small-to-Big 切分 → 稠密 + 稀疏向量化 → Qdrant 入库；提问时 → 意图路由 → 多路召回 → RRF 融合 → Rerank → 父块上下文扩展 → 知识块组装 → LLM 流式生成。

***

## 技术栈

| 分类    | 选型                                            | 说明                             |
| ----- | --------------------------------------------- | ------------------------------ |
| 后端    | Python 3.13 / FastAPI                         | API 服务，SSE 流式                  |
| 文档解析  | PyMuPDF / PDFPlumber / python-docx / openpyxl | 文本 + 表格 + 版式                   |
| OCR   | PaddleOCR AI Studio（ppocr）                    | 扫描件按需触发（文本提取率 <80%）            |
| 嵌入    | 百炼 API `qwen3.7-text-embedding`（DashScope 原生接口） | 稠密 1024 维 + 模型原生稀疏     |
| 稀疏向量  | 嵌入模型原生输出（词表 index + 语义权重，无 IDF modifier） | 与稠密同一次 API 返回        |
| 向量数据库 | Qdrant                                        | 稠密 + 稀疏同 collection，payload 过滤 |
| 检索    | RRF(k=60) + 百炼 API Rerank（`qwen3-rerank`）     | 多路召回 + 精排，可降级                  |
| LLM   | 阿里云套餐 `deepseek-v4-flash-0731`（主）/ `qwen3.7-plus`（轻量） | 多模型路由                  |
| 登记库   | SQLite（SQLAlchemy）                            | 文档 / 任务状态                      |

***

## 安装指南

### 环境要求

- Python 3.13+（实测 3.13.9）
- Docker（Qdrant / Redis 容器化）

### 1. 克隆仓库

```bash
git clone https://github.com/yanovoUltra/newrag.git
cd newrag
```

### 2. 后端安装

```bash
cd backend
python -m venv .venv
.\.venv\Scripts\pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/
```

### 3. 基础设施（Docker）

```bash
docker compose -f infra/docker-compose.yml up -d qdrant redis
```

### 4. 配置密钥

```bash
copy .env.example .env
# 编辑 .env，填入：
#   EMBEDDING_API_KEY（百炼嵌入密钥）
#   LLM_API_KEY / LLM_LIGHT_API_KEY（阿里云套餐密钥，主/轻量模型）
#   PPOCR_TOKEN（可选，扫描件 OCR 用）
```

***

## 使用说明

### 启动后端

```bash
cd backend
.\.venv\Scripts\python -m uvicorn app.main:app --reload --port 8000
```

启动后访问 <http://localhost:8000/docs> 查看 OpenAPI 文档。

### 核心流程

1. **上传文档**：`POST /api/v1/documents` 上传财报，异步解析入库。
2. **轮询任务**：`GET /api/v1/tasks/{task_id}` 查看解析进度，到 `indexed` 后可提问。
3. **发起问答**：`POST /api/v1/chat` SSE 流式返回答案与引用。

### API 示例

```bash
# 上传文档
curl -X POST http://localhost:8000/api/v1/documents \
  -F "file=@report.pdf" -F "org_id=demo"

# 发起问答（SSE 流式）
curl -N -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"question": "2024 年公司营业收入是多少？", "org_id": "demo"}'

# 健康检查
curl http://localhost:8000/healthz
```

### 财报数据获取工具

`backend/scripts/fetch_reports.py` 提供三路数据源（详见文件头部说明）：

```bash
python scripts/fetch_reports.py sec        # SEC EDGAR 10-K → DOCX
python scripts/fetch_reports.py sec-fin    # SEC XBRL companyfacts → 三大报表 Excel
python scripts/fetch_reports.py cninfo     # 巨潮资讯 A 股年报 → PDF
```

***

## 配置方法

复制 `.env.example` 为 `.env` 并填写（全部配置项见 `.env.example` / `backend/app/core/config.py`）。

| 配置项                                                                       | 说明                                      | 默认值             |
| ------------------------------------------------------------------------- | --------------------------------------- | --------------- |
| `EMBEDDING_API_KEY`                                                       | 百炼嵌入密钥（qwen3.7-text-embedding，稠密 1024 维 + 原生稀疏） | -               |
| `MAX_EMBED_CONCURRENCY`                                                  | 嵌入 API 并发上限（超限排队，防 429；实测 8 为吞吐/稳定性平衡点）    | `8`             |
| `LLM_API_KEY`                                                             | 主模型密钥（阿里云套餐 token-plan 端点）          | -               |
| `LLM_LIGHT_MODEL`                                                         | 轻量模型（simple 问题路由）                       | `qwen3.7-plus` |
| `RERANK_BACKEND`                                                          | `api`（百炼 workspace 网关）\| `none`（RRF 直出） | `none`          |
| `RERANK_API_KEY` / `RERANK_API_BASE` / `RERANK_API_PATH`                  | 百炼 rerank 服务（`qwen3-rerank`）            | workspace 网关    |
| `PPOCR_TOKEN`                                                             | PaddleOCR AI Studio 在线 OCR 令牌（扫描件用）     | -               |
| `OCR_ENABLED`                                                             | 是否启用 OCR（图片上传需为 true）                   | `false`         |
| `CHUNK_TARGET_TOKENS` / `CHUNK_PARENT_TARGET_TOKENS` / `TABLE_MAX_TOKENS` | 切分参数（叶子 200 / 章节父块 3072 / 表格阈值 2048）    | 见左              |
| `RECALL_*_TOP_K` / `RRF_K` / `RETRIEVAL_TOP_K`                            | 检索参数                                    | 50/50/20/60/8   |
| `AUTH_ENABLED` / `AUTH_CLIENT_KEY` / `AUTH_SECRET`                        | API HMAC 签名认证（+`AUTH_TIMESTAMP_WINDOW`=300s / `AUTH_NONCE_TTL`=300s） | `false`          |
| `CHAT_TIMEOUT` / `INGEST_TIMEOUT`                                        | SSE 会话超时 / 入库任务级超时（秒）                    | 180 / 1800       |
| `QA_RECORD_ENABLED` / `GUARD_ENABLED` / `GUARD_INJECTION_TRIGGER_WORDS`  | 问答记录落库 / 注入防线开关 / 自定义注入关键词              | `true` / `true` / `` |
| `CLEAN_PAGE_NUMBERS`                                                     | 页码行剔除（页首页尾边缘区）                          | `true`          |
| `SPARSE_IDF_ENABLED` / `SPARSE_IDF_PATH`                                | 文档侧 IDF 重写开关 / index→IDF 映射文件              | `true` / `data/idf.json` |
| `STRUCTURAL_CHUNK_ENABLED`                                            | 结构块标记并置后降权（原 off/exclude 多模式已移除，仅保留降权）  | `true`          |

密钥一律只写 `.env`（已 gitignore），不得硬编码；认证密钥不打印日志。

***

## 目录结构

```text
newrag/
├── backend/
│   ├── app/
│   │   ├── main.py            # FastAPI 入口（/api/v1/*，healthz，认证中间件）
│   │   ├── core/              # config.py（.env 配置）/ logging.py / security.py（HMAC 认证）
│   │   ├── api/v1/            # documents / tasks / chat
│   │   ├── models/            # SQLAlchemy：Document / Task / ChatRecord / EvalResult
│   │   ├── parsers/           # layout（含双栏检测）/ ocr(ppocr) / structure(章节树) / clean(清洗)
│   │   ├── splitter/          # chunker（Small-to-Big）/ tokens
│   │   ├── embed/             # embedder（DashScope 原生 API，稠密+稀疏）
│   │   ├── store/             # qdrant / registry（SQLite + 落盘 + 问答/评测记录）/ redisx
│   │   ├── retrieval/         # search（混合检索）/ router（意图路由）/ reranker / rrf / idf（文档侧 IDF 重写）
│   │   ├── generation/        # prompts / llm（多模型路由）/ grounding（接地校验）/ guard（注入防线）
│   │   └── pipelines/         # ingest（入库，含超时+补偿）/ answer（问答 SSE）
│   ├── scripts/               # eval_ablation.py / eval_idf_structural.py / eval_adversarial.py / eval_all.py（统一评测入口）/ rebuild_idf_from_pipeline.py / migrate_structural.py / ablation_report.md
│   ├── tests/                 # pytest（87 用例）
│   └── requirements.txt
├── frontend/                  # 阶段三：Vue3 + Vite + TS + Element Plus
│   ├── src/views/             # ChatView（SSE 问答）/ DocumentsView / UploadView
│   ├── src/api/               # sse（fetch+ReadableStream）/ documents / chat
│   ├── src/styles/theme.css   # 设计令牌（AI-Native 暗色）
│   ├── e2e/                   # Playwright 端到端（chat.spec.ts）
│   ├── playwright.config.ts
│   └── vite.config.ts         # dev 代理 /api → http://localhost:8000
├── infra/docker-compose.yml   # qdrant + redis
├── .env.example
├── PROMPT.md / DESIGN.md / INSTALL_RECORD.md
└── data/                      # 运行时数据（gitignore）
```

***

## 阶段状态

| 阶段  | 内容                                                        | 状态   |
| --- | --------------------------------------------------------- | ---- |
| 阶段一 | 最小闭环：解析切分入库 + 单路检索 + SSE 问答                               | ✅ 完成 |
| 阶段二 | 检索增强：混合检索 + RRF + Rerank + 路由/改写/HyDE + Small-to-Big 检索消费 | ✅ 完成 |
| 阶段三 | 前端：Vue3 上传 / 问答 / 引用回跳                                    | ✅ 完成 |
| 阶段四 | 工程化：认证鉴权 / 超时 / 补偿 / Agent 防线 / 版本控制 / 数据清洗 / 存储 / **Celery 异步 / 增量索引 / OTel 可观测** | ✅ 完成 |
| 阶段五 | 评估：RAGAS 评测（faithfulness / answer\_relevancy / context\_precision / context\_recall）+ 检索消融网格、前端测试 | ✅ 完成（RAGAS 全量基线待补跑） |

### 阶段四详情（工程化收尾：异步任务 · 增量索引 · 可观测）

**① Celery 异步（ingest 任务与 API 进程解耦）**
- `app/tasks/celery_app.py`（broker=Redis，JSON 序列化）+ `app/tasks/ingest_task.py`（`ingest.run` 显式绑定 celery_app）
- 上传接口按 `TASK_BACKEND` 分派：`celery` → 独立 worker 执行（可重试/横向扩展）/ 默认 `background`（FastAPI BackgroundTasks，无 worker 环境零影响）
- 任务状态沿用 SQLite Task 表（跨进程共享，未引 result backend，API 轮询不变）
- 启动：`cd backend; .\.venv\Scripts\celery.exe -A app.tasks.celery_app worker -P solo --loglevel=info`
- **量化**：端到端验证提交→worker 执行→SQLite 状态 success 全链路通过；与评测并发化（299 题 249.5s）共同构成任务/评测两套异步体系

**② 增量索引（按文档维护，免全量重建）**
- `scripts/index_maintenance.py` 四命令：`stats` 汇总 / `check` 对账（孤儿点/缺块/残留点，异常退出码 1）/ `restore --doc`（从 pipeline stage 重入向量，**无需源文件、不调嵌入 API**）/ `reindex --doc --file`（参数变更后全量重建）
- **量化**：16 个 indexed 文档（28,424 块）Qdrant 点数与 registry 全量一致，零不一致
- 详细日志：不一致项输出完整 doc 元数据 + 块级 chunk_id 抽样（JSON 结构化，trace_id 关联），便于排查数据不一致

**③ OTel 可观测（本地导出，零外部依赖）**
- `app/core/otel.py`：TracerProvider + ConsoleSpanExporter + MeterProvider + PeriodicExportingMetricReader（`OTEL_ENABLED=true` 启用）
- FastAPI 自动 instrumentation（请求级 span）+ 手动 span：`answer.search`（检索）/ `answer.generate`（生成）/ ingest 全阶段（`stage_*_s` 耗时）
- `app/core/metrics.py`：外部 API（嵌入/LLM/rerank）调用计数 / 失败计数 / 延迟直方图——外部 API 是系统最大瓶颈，调用量/延迟/错误率一目了然
- **简历要点**：请求级自动埋点 + 检索/生成/入库关键链路手动 span + 外部依赖三件套指标，一套代码完成"日志（JSON+trace_id）→ 指标 → 链路追踪"三级可观测闭环

> 简历可引用量化：可观测覆盖 4 条核心链路（HTTP/检索/生成/入库）× 3 类外部 API 指标；任务系统与 API 进程解耦，worker 可独立扩展；索引对账 28,424 块零不一致。

***

## 常见问题

**Q：ppocr 对非扫描 PDF 也会触发吗？**
A：不会。仅当整文档文本提取率 <80% 且 `OCR_ENABLED=true` 时触发；文本 PDF 直接走版式层，无损且免费。

**Q：yahoo 数据源还能用吗？**
A：已移除。本网络下 yfinance 被 Yahoo 硬封锁（403 反爬），改用 SEC EDGAR XBRL companyfacts（`sec-fin`，无 key）获取美股三大报表，实测数据正确。

**Q：嵌入/重排 API 密钥能用在公共端点吗？**
A：嵌入（dashscope 公共端点，运行时映射原生 /api/v1）可以；rerank 的 `sk-ws-*` 密钥必须配 workspace 网关域名（`ws-*.maas.aliyuncs.com`），公共端点返回 400/Access denied。

**Q：切分后块数变化？**
A：碎片化修复后分块量约降 15 倍（浦发年报 34,550 → 4,135 块，叶子中位 token 176）；章节父块 95% 落在 2\~4K token 区间。

**Q：批量入库为什么慢？嵌入并发怎么调？**
A：历史根因是嵌入 `_call` 串行逐批调用，`max_embed_concurrency` 信号量从未生效（实测仅 3.1 texts/s）。已改为 `ThreadPoolExecutor` 并发发送各批，吞吐提升至约 9.9 texts/s（并发 4→8→12 实测 7.9→9.9→11.0，过高并发易触发 429，故取 8 为平衡点）。入库另有 Qdrant 写超时 `timeout=120` 与 `INGEST_TIMEOUT` 双层兜底。

**Q：自动化测试怎么跑？**
A：后端 `cd backend && .\.venv\Scripts\python -m pytest -q`（147 用例，mock 嵌入/LLM，不依赖真实模型）；前端单测 `cd frontend && npm test`（Vitest，SSE 与日期工具共 13 用例）；E2E `npm run test:e2e`（Playwright，需后端 8000 运行，覆盖导航/流式问答/注入拦截）。测试均为真实行为断言，非为过测试而凑。

**Q：RAGAS 评测结果在哪？**
A：`backend/scripts/eval_ragas.py`（自实现论文一致四指标，生产 rerank 口径 + 分层抽样 100 题 + deepseek-v4-flash 统一生成/评判；context_precision 用 golden 相关块确定性计算，零额外 LLM 调用；每问 ~4 次 LLM 调用）。dry-run 10 题基线（seed=42，全指标）：faithfulness **0.9333** / answer_relevancy **0.9813** / context_precision **0.9458** / context_recall **0.9261**；全量 100 题基线待补跑。结果落 `eval_results` 表。检索消融见 `backend/scripts/ablation_report.md`（结论：三路 RRF+rerank 最优 0.218；BM25 基线已移除，历史实测仅 0.0122，不建议重做）。

**Q：稀疏路"同词不同义"噪声怎么解决的？**
A：诊断发现噪声来自"财务报表结构表头/版式块"（含 `2024`/`本集团`/`人民币百万元` 等泛化 index，score 高但非答案）。**只用查询端 IDF 无效**（实测 0.090→0.083，表头块 doc 侧未降权）；正确解法是**文档侧 IDF 重写**：`backend/scripts/rebuild_idf.py --rewrite` 统计全 corpus 稀疏 index 文档频率，乘 IDF 重写 collection 稀疏点。实测三路 RRF 0.188→0.196、d0.7/s0.3 加权 0.114→0.130。新入库通过 `SPARSE_IDF_ENABLED` 自动应用同一 IDF。另配 `STRUCTURAL_CHUNK_ENABLED` 对独立纯版式块打标降权（完整表格块含数据不降权）。

***

## 许可证信息

本项目采用 \[MIT] 许可证，详见 [LICENSE](LICENSE) 文件。
